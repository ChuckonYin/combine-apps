//
//  App1.h
//  App1
//
//  Created by 尹绪坤(YINXUKUN137) on 2018/1/23.
//  Copyright © 2018年 尹绪坤(YINXUKUN137). All rights reserved.
//

#import <UIKit/UIkit.h>

@interface App2 : NSObject

+ (UIViewController *)startVC;

@end
