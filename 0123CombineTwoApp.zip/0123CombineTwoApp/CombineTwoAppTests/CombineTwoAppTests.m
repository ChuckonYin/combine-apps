//
//  CombineTwoAppTests.m
//  CombineTwoAppTests
//
//  Created by 尹绪坤(YINXUKUN137) on 2018/1/23.
//  Copyright © 2018年 尹绪坤(YINXUKUN137). All rights reserved.
//

#import <XCTest/XCTest.h>

@interface CombineTwoAppTests : XCTestCase

@end

@implementation CombineTwoAppTests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
