//
//  ViewController.m
//  CombineTwoApp
//
//  Created by 尹绪坤(YINXUKUN137) on 2018/1/23.
//  Copyright © 2018年 尹绪坤(YINXUKUN137). All rights reserved.
//

#import "ViewController.h"
#import "App1.h"
#import "App2.h"

@interface ViewController ()

@property (nonatomic, strong) UIButton *app1;

@property (nonatomic, strong) UIButton *app2;

@end

@implementation ViewController

- (void)openApp1:(id)sender {
    [self.navigationController pushViewController:[App1 startVC] animated:YES];
}


- (void)openApp2:(id)sender {
    [self.navigationController pushViewController:[App2 startVC] animated:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"入口";
    
    [self.view addSubview:self.app1];
    
    [self.view addSubview:self.app2];
    
}

- (UIButton *)app1 {
    if (!_app1) {
        _app1 = [[UIButton alloc] initWithFrame:CGRectMake(0, 100, 100, 100)];
        [_app1 setTitle:@"app1" forState:UIControlStateNormal];
        [_app1 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_app1 addTarget:self action:@selector(openApp1:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _app1;
}

- (UIButton *)app2 {
    if (!_app2) {
        _app2 = [[UIButton alloc] initWithFrame:CGRectMake(0, 200, 100, 100)];
        [_app2 setTitle:@"app2" forState:UIControlStateNormal];
        [_app2 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_app2 addTarget:self action:@selector(openApp2:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _app2;
}

@end
