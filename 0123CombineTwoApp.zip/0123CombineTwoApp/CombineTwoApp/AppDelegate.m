//
//  AppDelegate.m
//  CombineTwoApp
//
//  Created by 尹绪坤(YINXUKUN137) on 2018/1/23.
//  Copyright © 2018年 尹绪坤(YINXUKUN137). All rights reserved.
//

#import "AppDelegate.h"
#import "ViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    self.window.rootViewController = [[UINavigationController alloc] initWithRootViewController:[[ViewController alloc] init]];
    self.window.backgroundColor = [UIColor whiteColor];
    
    return YES;
}

@end
